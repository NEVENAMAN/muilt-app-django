from django.apps import AppConfig


class AppTwoConfig(AppConfig):
    name = 'app_two'
